### YOUTUBE FIX 

This is an utility to unbrick volumio devices with the youtube plugin 

IMPORTANT: 
- Your device must be off when this procedure starts 
- Your device must be turned on when requested (point 5)
- Make sure your device is connected to the same network as your PC 

1) Download Nodejs 

Windows 
https://nodejs.org/dist/v18.17.0/node-v18.17.0-x64.msi


MAC 
https://nodejs.org/dist/v18.17.0/node-v18.17.0.pkg

2) Install Nodejs 

3) Download and unpack this utility 

https://github.com/volumio/youtube-fix/archive/refs/heads/master.zip

Unpack this utility 

4) Open in a terminal with 

node index.js 

5) Turn on the affected device 

6) After 2 minutes from starting up your device, please restart it (remove and reattach power)

